package com.example.shortcuts

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.RemoteViews
import android.widget.Toast
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

object Intents {
    const val ACTION_RUN = "com.example.shortcuts.RUN"
    const val EXTRA_ID = "id"
    const val EXTRA_NAME = "name"
}

object Integrations {

    fun runIntent(ctx: Context, id: String): Intent =
        Intent(ctx, MainActivity::class.java)
            .setAction(Intents.ACTION_RUN)
            .putExtra(Intents.EXTRA_ID, id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)

    fun iconBitmap(sc: Shortcut): Bitmap {
        val size = 192
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = TileColors[((sc.color % TileColors.size) + TileColors.size) % TileColors.size].toInt()
        c.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), 40f, 40f, p)
        p.color = 0xFFFFFFFF.toInt()
        p.textSize = 96f
        p.textAlign = Paint.Align.CENTER
        val y = size / 2f - (p.descent() + p.ascent()) / 2f
        c.drawText(sc.glyph, size / 2f, y, p)
        return bmp
    }

    private fun info(ctx: Context, sc: Shortcut) =
        ShortcutInfoCompat.Builder(ctx, "sc-" + sc.id)
            .setShortLabel(sc.name.take(24))
            .setLongLabel(sc.name)
            .setIntent(runIntent(ctx, sc.id))
            .setIcon(IconCompat.createWithBitmap(iconBitmap(sc)))
            .build()

    /** Add a shortcut icon to the launcher's home screen. */
    fun pin(ctx: Context, sc: Shortcut) {
        if (ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
            ShortcutManagerCompat.requestPinShortcut(ctx, info(ctx, sc), null)
        } else {
            Toast.makeText(ctx, "Your launcher does not support pinning", Toast.LENGTH_SHORT).show()
        }
    }

    /** Publish top shortcuts to the launcher long-press menu and refresh widgets. */
    fun refresh(ctx: Context) {
        try {
            val max = ShortcutManagerCompat.getMaxShortcutCountPerActivity(ctx).coerceAtMost(4)
            val list = Store.sorted(Store.items.toList()).take(max).map { info(ctx, it) }
            ShortcutManagerCompat.setDynamicShortcuts(ctx, list)
        } catch (e: Exception) { }
        try { ShortcutsWidgetProvider.updateAll(ctx) } catch (e: Exception) { }
    }
}

class ShortcutsWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        Store.load(context.applicationContext)
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, build(context))
    }

    companion object {
        private val tiles = intArrayOf(R.id.t1, R.id.t2, R.id.t3, R.id.t4)
        private val bgs = intArrayOf(R.id.b1, R.id.b2, R.id.b3, R.id.b4)
        private val labels = intArrayOf(R.id.l1, R.id.l2, R.id.l3, R.id.l4)

        fun build(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_shortcuts)
            val list = Store.sorted(Store.items.toList()).take(4)
            for (i in 0 until 4) {
                val sc = list.getOrNull(i)
                if (sc == null) {
                    rv.setTextViewText(labels[i], "")
                    rv.setInt(bgs[i], "setColorFilter", 0x22888888)
                    rv.setOnClickPendingIntent(tiles[i], null)
                } else {
                    rv.setTextViewText(labels[i], sc.glyph + "  " + sc.name)
                    rv.setInt(bgs[i], "setColorFilter", TileColors[((sc.color % TileColors.size) + TileColors.size) % TileColors.size].toInt())
                    val pi = PendingIntent.getActivity(
                        ctx, 100 + i, Integrations.runIntent(ctx, sc.id),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    rv.setOnClickPendingIntent(tiles[i], pi)
                }
            }
            return rv
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ShortcutsWidgetProvider::class.java))
            if (ids.isNotEmpty()) for (id in ids) mgr.updateAppWidget(id, build(ctx))
        }
    }
}

/** Quick Settings tiles: each tile runs the n-th shortcut that has "Show in Quick Settings" enabled. */
abstract class BaseTile(private val slot: Int) : TileService() {

    private fun target(): Shortcut? {
        Store.load(applicationContext)
        return Store.items.filter { it.qs }.getOrNull(slot)
    }

    override fun onStartListening() {
        val sc = target()
        val t = qsTile ?: return
        t.label = sc?.name ?: "Shortcut ${slot + 1}"
        t.state = if (sc != null) Tile.STATE_INACTIVE else Tile.STATE_UNAVAILABLE
        t.updateTile()
    }

    @Suppress("DEPRECATION")
    override fun onClick() {
        val sc = target() ?: return
        val i = Integrations.runIntent(this, sc.id)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(this, 200 + slot, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            startActivityAndCollapse(pi)
        } else {
            startActivityAndCollapse(i)
        }
    }
}

class Tile1 : BaseTile(0)
class Tile2 : BaseTile(1)
class Tile3 : BaseTile(2)
