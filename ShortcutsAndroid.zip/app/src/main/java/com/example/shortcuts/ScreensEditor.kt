package com.example.shortcuts

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class ActiveField(val key: String, val stepIndex: Int, val insert: (String) -> Unit)

private val openers = setOf("if", "repeat", "repeat_each", "menu")
private val closers = setOf("endif", "endrepeat", "endmenu")
private val markers = setOf("else", "endif", "endrepeat", "menu_item", "endmenu")

private fun blockEnd(steps: List<Step>, start: Int): Int {
    var depth = 0
    for (i in start until steps.size) {
        val t = steps[i].type
        if (t in openers) depth++
        if (t in closers) {
            depth--
            if (depth == 0) return i
        }
    }
    return start
}

private fun computeDepths(steps: List<Step>): List<Int> {
    val out = ArrayList<Int>()
    var d = 0
    for (s in steps) {
        when (s.type) {
            "endif", "endrepeat", "endmenu" -> { d = maxOf(0, d - 1); out.add(d) }
            "else" -> out.add(maxOf(0, d - 1))
            "menu_item" -> out.add(maxOf(0, d - 1))
            "if", "repeat", "repeat_each", "menu" -> { out.add(d); d++ }
            else -> out.add(d)
        }
    }
    return out
}

private fun moveStep(sc: Shortcut, idx: Int, delta: Int) {
    val to = idx + delta
    if (to < 0 || to >= sc.steps.size) return
    val list = sc.steps.toMutableList()
    val tmp = list[idx]
    list[idx] = list[to]
    list[to] = tmp
    Store.update(sc.copy(steps = list))
}

private fun removeStep(sc: Shortcut, idx: Int) {
    val step = sc.steps[idx]
    val end: Int
    if (step.type in openers) {
        end = blockEnd(sc.steps, idx)
    } else if (step.type == "menu_item") {
        // remove this menu item and the actions under it, up to the next item or the end of the menu
        var e = idx
        var depth = 0
        for (i in idx + 1 until sc.steps.size) {
            val t = sc.steps[i].type
            if (depth == 0 && (t == "menu_item" || t == "endmenu")) break
            if (t in openers) depth++
            if (t in closers) depth--
            e = i
        }
        end = e
    } else {
        end = idx
    }
    val keepSteps = sc.steps.filterIndexed { i, _ -> i < idx || i > end }
    Store.update(sc.copy(steps = keepSteps))
}

private fun addMenuItem(sc: Shortcut, menuIdx: Int) {
    val end = blockEnd(sc.steps, menuIdx)
    val count = sc.steps.subList(menuIdx, end).count { it.type == "menu_item" } + 1
    val list = sc.steps.toMutableList()
    list.add(end, Catalog.newStep("menu_item").p("title", "Item $count"))
    Store.update(sc.copy(steps = list))
}

// ---------------- Editor ----------------

@Composable
fun EditorScreen(nav: Nav, id: String) {
    val sc = Store.get(id)
    if (sc == null) {
        LaunchedEffect(Unit) { nav.pop() }
        return
    }
    var active by remember { mutableStateOf<ActiveField?>(null) }
    val depths = computeDepths(sc.steps)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                LinkText("‹") { nav.pop() }
                Row(
                    Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).clickable { nav.push(Route.Details(sc.id)) }.padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlyphBox(sc.glyph, tileColor(sc.color), 32.dp, 8.dp)
                    Text(sc.name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.padding(start = 8.dp))
                }
                LinkText("▶") { nav.run(sc) }
                LinkText("ⓘ") { nav.push(Route.Details(sc.id)) }
            }
        },
        bottomBar = {
            val a = active
            if (a != null) {
                VarBar(sc, a) { active = null }
            } else {
                Surface(color = MaterialTheme.colorScheme.surface) {
                    Row(
                        Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { nav.push(Route.Picker(sc.id)) }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🔍  Search for apps and actions", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (sc.steps.isEmpty()) {
                item {
                    Text(
                        "Your shortcut is empty.\nTap the search bar below to add actions.",
                        color = Ios.gray, modifier = Modifier.padding(32.dp)
                    )
                }
            }
            items(sc.steps.size, key = { sc.steps[it].id }) { idx ->
                StepCard(sc, idx, depths[idx], active) { active = it }
            }
        }
    }
}

@Composable
fun StepCard(sc: Shortcut, idx: Int, depth: Int, active: ActiveField?, onActive: (ActiveField?) -> Unit) {
    val step = sc.steps[idx]
    val def = Catalog.byType[step.type]
    val isCloser = step.type in setOf("endif", "endrepeat", "endmenu")
    val cat = def?.category ?: "Scripting"
    val color = Color(CatColors[cat] ?: 0xFF8E8E93)

    Column(
        Modifier.fillMaxWidth().padding(start = (depth * 14).dp)
            .clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlyphBox(def?.glyph ?: "?", color, 30.dp, 8.dp)
            Text(def?.title ?: step.type, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
                modifier = Modifier.padding(start = 10.dp).weight(1f))
            if (!isCloser && step.type != "else") {
                if (step.type !in openers && step.type != "menu_item") {
                    Text("↑", color = Ios.blue, fontSize = 20.sp, modifier = Modifier.clickable { moveStep(sc, idx, -1) }.padding(8.dp))
                    Text("↓", color = Ios.blue, fontSize = 20.sp, modifier = Modifier.clickable { moveStep(sc, idx, 1) }.padding(8.dp))
                }
                Text("✕", color = Ios.red, fontSize = 16.sp, modifier = Modifier.clickable { removeStep(sc, idx) }.padding(8.dp))
            }
        }
        def?.params?.forEach { p -> ParamField(sc, step, idx, p, onActive) }
        if (step.type == "menu") {
            TextButton(onClick = { addMenuItem(sc, idx) }) { Text("＋ Add Menu Item") }
        }
    }
}

@Composable
fun ParamField(sc: Shortcut, step: Step, idx: Int, p: Param, onActive: (ActiveField?) -> Unit) {
    val value = step.params[p.key] ?: p.def
    fun set(v: String) {
        Store.update(sc.copy(steps = sc.steps.map {
            if (it.id == step.id) it.copy(params = it.params + (p.key to v)) else it
        }))
    }
    val opts = p.options
    if (opts != null) {
        var open by remember { mutableStateOf(false) }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(p.label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Box {
                Text(
                    "$value ⌄", color = Ios.blue, fontSize = 15.sp,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { open = true }.padding(horizontal = 10.dp, vertical = 6.dp)
                )
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    opts.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { set(o); open = false }) }
                }
            }
        }
    } else {
        val key = step.id + ":" + p.key
        var tfv by remember(step.id, p.key) { mutableStateOf(TextFieldValue(value)) }
        if (tfv.text != value) tfv = TextFieldValue(value, TextRange(value.length))
        val transform = remember(sc.steps) { TokenTransformation { tok -> tokenLabel(sc, tok) } }
        OutlinedTextField(
            value = tfv,
            onValueChange = { nv ->
                val fixed = fixDeletion(tfv, nv)
                tfv = fixed
                set(fixed.text)
            },
            label = { Text(p.label) },
            visualTransformation = transform,
            minLines = if (p.multiline) 3 else 1,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp).onFocusChanged { fs ->
                if (fs.isFocused) {
                    onActive(ActiveField(key, idx) { tok ->
                        val sel = tfv.selection
                        val txt = tfv.text.substring(0, sel.min) + tok + tfv.text.substring(sel.max)
                        tfv = TextFieldValue(txt, TextRange(sel.min + tok.length))
                        set(txt)
                    })
                }
            }
        )
    }
}

@Composable
fun VarBar(sc: Shortcut, active: ActiveField, onClose: () -> Unit) {
    val focus = LocalFocusManager.current
    val chips = ArrayList<Pair<String, String>>()
    chips.add("Ask Each Time" to "Ask Each Time")
    chips.add("Clipboard" to "Clipboard")
    chips.add("Current Date" to "Current Date")
    chips.add("Shortcut Input" to "Shortcut Input")
    chips.add("Repeat Item" to "Repeat Item")
    chips.add("Repeat Index" to "Repeat Index")
    for (i in 0 until minOf(active.stepIndex, sc.steps.size)) {
        val st = sc.steps[i]
        val d = Catalog.byType[st.type]
        if (d != null && d.hasOutput) chips.add(("=" + st.id) to d.title)
    }
    sc.steps.filter { it.type == "set_var" || it.type == "add_var" }
        .mapNotNull { it.params["name"] }.distinct()
        .forEach { chips.add(("@" + it) to it) }

    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("✕", modifier = Modifier.clickable { focus.clearFocus(); onClose() }.padding(horizontal = 14.dp, vertical = 8.dp), color = Ios.gray)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(end = 12.dp)) {
                items(chips) { c ->
                    Text(
                        c.second, color = Color.White, fontSize = 14.sp,
                        modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Ios.blue)
                            .clickable { active.insert("{{" + c.first + "}}") }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }
        }
    }
}

// ---------------- Action picker ----------------

@Composable
fun PickerScreen(nav: Nav, shortcutId: String) {
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Add Action", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp).weight(1f))
            LinkText("Done") { nav.pop() }
        }
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            placeholder = { Text("Search for apps and actions") },
            leadingIcon = { Text("🔍") },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
        )
        val defs = Catalog.pickable.filter {
            q.isBlank() || it.title.contains(q, true) || it.desc.contains(q, true) || it.category.contains(q, true)
        }
        LazyColumn(Modifier.weight(1f)) {
            for (cat in Catalog.categories) {
                val list = defs.filter { it.category == cat }
                if (list.isEmpty()) continue
                item(key = "h-$cat") {
                    Text(cat, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 6.dp))
                }
                items(list, key = { it.type }) { a ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            val sc = Store.get(shortcutId)
                            if (sc != null) Store.update(sc.copy(steps = sc.steps + Catalog.instantiate(a.type)))
                            nav.pop()
                        }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GlyphBox(a.glyph, Color(CatColors[a.category] ?: 0xFF8E8E93), 36.dp, 9.dp)
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(a.title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            if (a.desc.isNotEmpty()) Text(a.desc, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
