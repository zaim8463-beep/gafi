package com.example.shortcuts

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Ios {
    val blue = Color(0xFF007AFF)
    val red = Color(0xFFFF3B30)
    val green = Color(0xFF34C759)
    val gray = Color(0xFF8E8E93)
}

@Composable
fun IosTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) darkColorScheme(
        primary = Ios.blue,
        background = Color.Black,
        surface = Color(0xFF1C1C1E),
        surfaceVariant = Color(0xFF2C2C2E),
        onBackground = Color.White,
        onSurface = Color.White,
        onSurfaceVariant = Color(0xFFAEAEB2),
        surfaceContainer = Color(0xFF1C1C1E),
        surfaceContainerHigh = Color(0xFF2C2C2E)
    ) else lightColorScheme(
        primary = Ios.blue,
        background = Color(0xFFF2F2F7),
        surface = Color.White,
        surfaceVariant = Color(0xFFE9E9EE),
        onBackground = Color.Black,
        onSurface = Color.Black,
        onSurfaceVariant = Color(0xFF6C6C70),
        surfaceContainer = Color.White,
        surfaceContainerHigh = Color.White
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

fun tileColor(i: Int): Color = Color(TileColors[((i % TileColors.size) + TileColors.size) % TileColors.size])

@Composable
fun GlyphBox(glyph: String, color: Color, size: Dp, radius: Dp = 10.dp, modifier: Modifier = Modifier) {
    Box(
        modifier.size(size).clip(RoundedCornerShape(radius)).background(color),
        contentAlignment = Alignment.Center
    ) { Text(glyph, fontSize = (size.value * 0.5f).sp) }
}

@Composable
fun LinkText(text: String, color: Color = Ios.blue, onClick: () -> Unit) {
    Text(
        text, color = color, fontSize = 17.sp,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 8.dp)
    )
}

@Composable
fun Group(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface),
        content = content
    )
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text.uppercase(), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 6.dp)
    )
}

fun tokenLabel(sc: Shortcut?, tok: String): String = when {
    tok.startsWith("=") -> {
        val step = sc?.steps?.firstOrNull { it.id == tok.substring(1) }
        if (step == null) "Missing" else (Catalog.byType[step.type]?.title ?: step.type)
    }
    tok.startsWith("@") -> tok.substring(1)
    tok == "Result" -> "Previous Result"
    else -> tok
}

/** Shows {{variable}} tokens as blue pills while the stored text keeps the raw token. */
class TokenTransformation(private val label: (String) -> String) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val src = text.text
        if (!src.contains("{{")) return TransformedText(text, OffsetMapping.Identity)
        val sb = StringBuilder()
        val o2t = IntArray(src.length + 1)
        val t2o = ArrayList<Int>()
        val spans = ArrayList<IntArray>()
        var pos = 0

        fun plain(upTo: Int) {
            while (pos < upTo) {
                o2t[pos] = sb.length
                t2o.add(pos)
                sb.append(src[pos])
                pos++
            }
        }

        for (m in TokenRe.findAll(src)) {
            plain(m.range.first)
            val a = m.range.first
            val b = m.range.last + 1
            val lab = " " + label(m.groupValues[1]) + " "
            val st = sb.length
            for (k in a until b) o2t[k] = st
            for (k in 0 until lab.length) t2o.add(if (k == 0) a else b)
            sb.append(lab)
            spans.add(intArrayOf(st, sb.length))
            pos = b
        }
        plain(src.length)
        o2t[src.length] = sb.length
        t2o.add(src.length)

        val annotated = buildAnnotatedString {
            append(sb.toString())
            for (s in spans) addStyle(SpanStyle(color = Color.White, background = Ios.blue), s[0], s[1])
        }
        val mapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int = o2t[offset.coerceIn(0, src.length)]
            override fun transformedToOriginal(offset: Int): Int = t2o[offset.coerceIn(0, t2o.size - 1)]
        }
        return TransformedText(annotated, mapping)
    }
}

/** Backspace over a pill removes the whole {{token}}. */
fun fixDeletion(old: androidx.compose.ui.text.input.TextFieldValue, nw: androidx.compose.ui.text.input.TextFieldValue):
    androidx.compose.ui.text.input.TextFieldValue {
    val o = old.text
    val n = nw.text
    if (n.length >= o.length || !o.contains("{{")) return nw
    var p = 0
    while (p < n.length && p < o.length && n[p] == o[p]) p++
    var sfx = 0
    while (sfx < n.length - p && sfx < o.length - p && n[n.length - 1 - sfx] == o[o.length - 1 - sfx]) sfx++
    var a = p
    var b = o.length - sfx
    for (m in TokenRe.findAll(o)) {
        val s = m.range.first
        val e = m.range.last + 1
        if (s < b && e > a) { a = minOf(a, s); b = maxOf(b, e) }
    }
    val res = o.substring(0, a) + o.substring(b)
    return androidx.compose.ui.text.input.TextFieldValue(res, androidx.compose.ui.text.TextRange(a))
}
